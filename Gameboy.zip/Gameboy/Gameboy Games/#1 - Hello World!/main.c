#include <gb/gb.h>
#include <stdio.h>

void main() {
    printf("Hello World!");
}