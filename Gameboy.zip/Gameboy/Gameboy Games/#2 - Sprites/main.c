#include <gb/gb.h>
#include <stdio.h>
#include "sprites.c"

void main() {
    uint8_t current_sprite_index = 0;
    uint8_t in_reverse = 1;

    set_sprite_data(0, 3, Blobs);
    set_sprite_tile(0, 2);
    move_sprite(0, 88, 78);
    SHOW_SPRITES;

    while(1) {
        if(current_sprite_index == 0) {
            current_sprite_index = 2;
        } else if(current_sprite_index == 2 && in_reverse == 0) {
            current_sprite_index = 1;
            in_reverse = 1;
        } else if(current_sprite_index == 2 && in_reverse == 1) {
            current_sprite_index = 0;
            in_reverse = 0;
        } else {
            current_sprite_index = 2;
        }

        set_sprite_tile(0, current_sprite_index);
        delay(1000);

        scroll_sprite(0, 10, 0);
    }
}