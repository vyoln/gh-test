#include <gb/gb.h>
#include <stdio.h>

int16_t player_location[2];
BYTE jumping;
int8_t gravity = -2;
int16_t current_speed_y;
int16_t floor_y_pos = 100;

unsigned char person[] = {
  0x00,0x00,0x38,0x38,0x7C,0x44,0x7F,0x7F,
  0x44,0x74,0x46,0x7C,0x40,0x78,0x24,0x3C,
  0x18,0x3C,0x00,0x24,0x00,0x24,0x00,0x24,
  0x00,0x24,0x00,0x36,0x00,0x00,0x00,0x00,
  0x00,0x00,0x38,0x38,0x7C,0x44,0x7F,0x7F,
  0x44,0x74,0x46,0x7C,0x40,0x78,0x24,0x3C,
  0x18,0x3C,0x00,0x22,0x00,0x22,0x00,0x22,
  0x00,0x23,0x00,0x30,0x00,0x00,0x00,0x00,
  0x00,0x00,0x38,0x38,0x7C,0x44,0x7F,0x7F,
  0x44,0x74,0x46,0x7C,0x40,0x78,0x24,0x3C,
  0x18,0x3C,0x00,0x42,0x00,0x42,0x00,0x42,
  0x00,0x42,0x00,0x63,0x00,0x00,0x00,0x00,
  0x00,0x00,0x38,0x38,0x7C,0x44,0x7F,0x7F,
  0x44,0x74,0x46,0x7C,0x40,0x78,0x24,0x3C,
  0x18,0x3C,0x00,0x44,0x00,0x44,0x00,0x44,
  0x00,0x64,0x00,0x06,0x00,0x00,0x00,0x00
};

void perf_delay(uint8_t num_loops) {
    uint8_t i;
    for(i = 0; i < num_loops; i++) {
        wait_vbl_done();
    }
}

int8_t would_hit_surface(int16_t projected_y_pos) {
    if(projected_y_pos >= floor_y_pos) {
        return floor_y_pos;
    } 
    return -1;
}

void jump(uint8_t sprite_id, uint16_t sprite_location[2]) {
    int8_t possible_surface_y;

    if (jumping == 0) {
        jumping = 1;
        current_speed_y = 10;
    }

    current_speed_y = current_speed_y + gravity;

    sprite_location[1] = sprite_location[1] - current_speed_y;
    possible_surface_y = would_hit_surface(sprite_location[1]);

    if(possible_surface_y != -1) {
        jumping = 0;
        move_sprite(sprite_id, sprite_location[0], possible_surface_y);
    } 
    else {
        move_sprite(sprite_id, sprite_location[0], sprite_location[1]);
    }
}

void main() {
    set_sprite_data(0, 8, person);
    set_sprite_tile(0, 0);

    player_location[0] = 10;
    player_location[1] = floor_y_pos;
    jumping = 0;

    move_sprite(0, player_location[0], player_location[1]);

    DISPLAY_ON;
    SHOW_SPRITES;

    while(1) {
            if ((joypad() & J_A) || jumping == 1) {
                jump(0, player_location);
            }

            if(joypad() & J_LEFT) {
                player_location[0] = player_location[0] - 2;
                move_sprite(0, player_location[0], player_location[1]);
            }

            if(joypad() & J_RIGHT) {
                player_location[0] = player_location[0] + 2;
                move_sprite(0, player_location[0], player_location[1]);
            }
        
            perf_delay(2);
        }
    }