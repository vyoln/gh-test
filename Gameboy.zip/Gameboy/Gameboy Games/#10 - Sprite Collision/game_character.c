#include <gb/gb.h>

struct game_character {
    UBYTE sprite_ids[4];
    uint8_t x;
    uint8_t y;
    uint8_t width;
    uint8_t height;
};