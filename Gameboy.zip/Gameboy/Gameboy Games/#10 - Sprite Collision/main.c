#include <gb/gb.h>
#include <stdio.h>
#include "game_character.c"
#include "sprites.c"

struct game_character player;
struct game_character enemy;
UBYTE sprite_size = 8;

void perf_delay(uint8_t num_loops) {
    uint8_t i;
    for(i = 0; i < num_loops; i++) {
        wait_vbl_done();
    }
}

UBYTE check_collisions(struct game_character* one, struct game_character* two) {
    return (one -> x >= two -> x && one -> x <= two -> x + two -> width) && (one -> y >= two -> y && one -> y <= two -> y + two -> height) || (two -> x >= one -> x && two -> x <= one -> x + one -> width) && (two -> y >= one -> y && two -> y <= one -> y + one -> height);
}

void move_game_character(struct game_character* character, uint8_t x, uint8_t y) {
    move_sprite(character -> sprite_ids[0], x, y);
    move_sprite(character -> sprite_ids[1], x + sprite_size, y);
    move_sprite(character -> sprite_ids[2], x, y + sprite_size);
    move_sprite(character -> sprite_ids[3], x + sprite_size, y + sprite_size);
}

void setup_player() {
    player.x = 80;
    player.y = 130;
    player.width = 16;
    player.height = 16;

    set_sprite_tile(0, 0);
    player.sprite_ids[0] = 0;
    set_sprite_tile(1, 1);
    player.sprite_ids[1] = 1;
    set_sprite_tile(2, 2);
    player.sprite_ids[2] = 2;
    set_sprite_tile(3, 3);
    player.sprite_ids[3] = 3;

    move_game_character(&player, player.x, player.y);
}

void setup_enemy() {
    enemy.x = 30;
    enemy.y = 0;
    enemy.width = 16;
    enemy.height = 16;

    set_sprite_tile(4, 4);
    enemy.sprite_ids[0] = 4;
    set_sprite_tile(5, 5);
    enemy.sprite_ids[1] = 5;
    set_sprite_tile(6, 6);
    enemy.sprite_ids[2] = 6;
    set_sprite_tile(7, 7);
    enemy.sprite_ids[3] = 7;

    move_game_character(&enemy, enemy.x, enemy.y);
}

void main() {
    set_sprite_data(0, 8, sprites);

    setup_player();
    setup_enemy();

    DISPLAY_ON;
    SHOW_SPRITES;

    while(!check_collisions(&player, &enemy)) {
        if(joypad() & J_LEFT) {
            player.x -= 2;
            move_game_character(&player, player.x, player.y);
        } if(joypad() & J_RIGHT) {
            player.x += 2;
            move_game_character(&player, player.x, player.y);
        }

        enemy.y += 5;

        if(enemy.y >= 144+16) {
            enemy.y = 0;
            enemy.x = player.x;
        }

        move_game_character(&enemy, enemy.x, enemy.y);

        perf_delay(2);
    }

    printf("\n \n \n \n \n \n \n <<< GAME OVER! >>>");
}